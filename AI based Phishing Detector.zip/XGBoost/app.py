from flask import Flask, request, render_template, jsonify
import numpy as np
import joblib
import logging
from url_feature_extractor import extract_features, get_feature_names
import traceback
from urllib.parse import urlparse
import re

app = Flask(__name__)

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Load model
try:
    model = joblib.load("xgboost_model.pkl")
    logger.info("Model loaded successfully")
except Exception as e:
    logger.error(f"Error loading model: {e}")
    model = None

def validate_url(url):
    """Validate if the provided string is a valid URL"""
    try:
        # Add http:// if no scheme is provided
        if not url.startswith(('http://', 'https://')):
            url = 'http://' + url
        
        # Basic URL validation
        parsed = urlparse(url)
        if not parsed.netloc:
            return False, None
        
        # Check for valid domain format
        domain_pattern = re.compile(
            r'^[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?)*$'
        )
        
        if not domain_pattern.match(parsed.netloc.split(':')[0]):
            return False, None
            
        return True, url
    except Exception:
        return False, None

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get URL from form
        url = request.form.get('url', '').strip()
        
        if not url:
            return render_template("index.html", 
                                 error="Please enter a URL to analyze",
                                 url=url)
        
        # Validate URL
        is_valid, validated_url = validate_url(url)
        if not is_valid:
            return render_template("index.html", 
                                 error="Please enter a valid URL (e.g., example.com or https://example.com)",
                                 url=url)
        
        # Check if model is loaded
        if model is None:
            return render_template("index.html", 
                                 error="Model not loaded. Please check server logs.",
                                 url=url)
        
        logger.info(f"Analyzing URL: {validated_url}")
        
        # Extract features
        features = extract_features(validated_url)
        logger.info(f"Extracted {len(features)} features")
        
        # Validate feature count (should be 48)
        expected_features = 48
        if len(features) != expected_features:
            logger.warning(f"Expected {expected_features} features, got {len(features)}")
            return render_template("index.html", 
                                 error=f"Feature extraction error: Expected {expected_features} features, got {len(features)}",
                                 url=url)
        
        # Convert to numpy array
        features_array = np.array(features).reshape(1, -1)
        
        # Make prediction
        prediction = model.predict(features_array)[0]
        
        # Get prediction probability if available
        try:
            prediction_proba = model.predict_proba(features_array)[0]
            confidence = max(prediction_proba) * 100
        except:
            confidence = None
        
        # Determine result
        result = "Phishing" if prediction == 1 else "Legitimate"
        
        logger.info(f"Prediction for {validated_url}: {result}")
        
        return render_template("index.html", 
                             result=result,
                             url=validated_url,
                             confidence=confidence,
                             features_count=len(features))
        
    except Exception as e:
        logger.error(f"Error during prediction: {str(e)}")
        logger.error(traceback.format_exc())
        
        return render_template("index.html", 
                             error=f"An error occurred while analyzing the URL: {str(e)}",
                             url=request.form.get('url', ''))

@app.route('/api/predict', methods=['POST'])
def api_predict():
    """API endpoint for programmatic access"""
    try:
        data = request.get_json()
        if not data or 'url' not in data:
            return jsonify({'error': 'URL parameter is required'}), 400
        
        url = data['url'].strip()
        
        # Validate URL
        is_valid, validated_url = validate_url(url)
        if not is_valid:
            return jsonify({'error': 'Invalid URL format'}), 400
        
        # Check if model is loaded
        if model is None:
            return jsonify({'error': 'Model not available'}), 500
        
        # Extract features
        features = extract_features(validated_url)
        
        # Validate feature count
        if len(features) != 48:
            return jsonify({'error': f'Feature extraction error: Expected 48 features, got {len(features)}'}), 500
        
        # Make prediction
        features_array = np.array(features).reshape(1, -1)
        prediction = model.predict(features_array)[0]
        
        # Get confidence if possible
        try:
            prediction_proba = model.predict_proba(features_array)[0]
            confidence = float(max(prediction_proba))
        except:
            confidence = None
        
        result = {
            'url': validated_url,
            'prediction': 'phishing' if prediction == 1 else 'legitimate',
            'prediction_code': int(prediction),
            'confidence': confidence,
            'features_extracted': len(features)
        }
        
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"API Error: {str(e)}")
        return jsonify({'error': f'Internal server error: {str(e)}'}), 500

@app.route('/features')
def show_features():
    """Display feature information"""
    feature_names = get_feature_names()
    return render_template("features.html", features=feature_names)

@app.route('/health')
def health_check():
    """Health check endpoint"""
    status = {
        'status': 'healthy',
        'model_loaded': model is not None,
        'features_available': 48
    }
    return jsonify(status)

@app.errorhandler(404)
def not_found(error):
    return render_template("index.html", error="Page not found"), 404

@app.errorhandler(500)
def internal_error(error):
    logger.error(f"Internal server error: {error}")
    return render_template("index.html", error="Internal server error"), 500

if __name__ == '__main__':
    # Check if model file exists
    import os
    if not os.path.exists("xgboost_model.pkl"):
        logger.warning("Model file 'phishing_detector_model.pkl' not found!")
    
    app.run(debug=True, host='0.0.0.0', port=5000)