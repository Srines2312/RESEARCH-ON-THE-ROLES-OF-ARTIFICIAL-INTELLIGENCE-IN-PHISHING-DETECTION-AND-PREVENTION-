# url_feature_extractor.py

from urllib.parse import urlparse
import re
import socket
import requests
from bs4 import BeautifulSoup
import whois
import dns.resolver
from datetime import datetime
import ssl
import urllib3
from urllib.request import urlopen
import warnings

# Suppress SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
warnings.filterwarnings('ignore')

def has_ip_address(hostname):
    """Check if hostname is an IP address"""
    try:
        socket.inet_aton(hostname)
        return 1
    except:
        return 0

def get_page_content(url, timeout=10):
    """Safely get page content"""
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        response = requests.get(url, headers=headers, timeout=timeout, verify=False)
        return response.text, response
    except:
        return None, None

def get_domain_age(domain):
    """Get domain age in days"""
    try:
        domain_info = whois.whois(domain)
        if domain_info.creation_date:
            if isinstance(domain_info.creation_date, list):
                creation_date = domain_info.creation_date[0]
            else:
                creation_date = domain_info.creation_date
            age = (datetime.now() - creation_date).days
            return age
    except:
        pass
    return -1

def check_dns_record(domain):
    """Check if domain has DNS record"""
    try:
        dns.resolver.resolve(domain, 'A')
        return 1
    except:
        return 0

def check_google_index(url):
    """Check if URL is indexed by Google (simplified check)"""
    try:
        search_url = f"https://www.google.com/search?q=site:{url}"
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        response = requests.get(search_url, headers=headers, timeout=10)
        # Simple heuristic: if we get results, it's likely indexed
        return 1 if "did not match any documents" not in response.text else 0
    except:
        return 0

def extract_features(url):
    """Extract all 48 features from URL"""
    
    parsed = urlparse(url)
    hostname = parsed.hostname or ""
    path = parsed.path or ""
    query = parsed.query or ""
    domain = hostname.replace('www.', '') if hostname.startswith('www.') else hostname
    
    # Get page content for HTML-based features
    html_content, response = get_page_content(url)
    soup = BeautifulSoup(html_content, 'html.parser') if html_content else None
    
    sensitive_words = ['secure', 'account', 'update', 'login', 'signin', 'banking', 'verify']
    
    # Calculate features
    features = []
    
    # 1. NumDots
    features.append(url.count('.'))
    
    # 2. SubdomainLevel
    features.append(hostname.count('.'))
    
    # 3. PathLevel
    features.append(url.count('/'))
    
    # 4. UrlLength
    features.append(len(url))
    
    # 5. NumDash
    features.append(url.count('-'))
    
    # 6. NumDashInHostname
    features.append(hostname.count('-'))
    
    # 7. AtSymbol
    features.append(url.count('@'))
    
    # 8. TildeSymbol
    features.append(url.count('~'))
    
    # 9. NumUnderscore
    features.append(url.count('_'))
    
    # 10. NumPercent
    features.append(url.count('%'))
    
    # 11. NumQueryComponents
    features.append(query.count('=') + query.count('&'))
    
    # 12. NumAmpersand
    features.append(url.count('&'))
    
    # 13. NumHash
    features.append(url.count('#'))
    
    # 14. NumNumericChars
    features.append(len(re.findall(r'\d', url)))
    
    # 15. NoHttps
    features.append(int(not url.lower().startswith('https')))
    
    # 16. RandomString
    features.append(int(bool(re.search(r'/[a-zA-Z0-9]{10,}/', url))))
    
    # 17. IpAddress
    features.append(has_ip_address(hostname))
    
    # 18. DomainInSubdomains
    domain_parts = domain.split('.')
    subdomain_parts = hostname.replace(domain, '').split('.')
    features.append(int(any(part in subdomain_parts for part in domain_parts if part)))
    
    # 19. DomainInPaths
    features.append(int(any(part in path for part in domain.split('.') if part)))
    
    # 20. HttpsInHostname
    features.append(int('https' in hostname.lower()))
    
    # 21. HostnameLength
    features.append(len(hostname))
    
    # 22. PathLength
    features.append(len(path))
    
    # 23. QueryLength
    features.append(len(query))
    
    # 24. DoubleSlashInPath
    features.append(int('//' in path))
    
    # 25. NumSensitiveWords
    features.append(sum(word in url.lower() for word in sensitive_words))
    
    # 26. EmbeddedBrandName
    brand_names = ['paypal', 'bank', 'amazon', 'google', 'microsoft', 'apple', 'facebook']
    features.append(int(any(brand in url.lower() for brand in brand_names)))
    
    # HTML-based features (27-45)
    if soup:
        # 27. PctExtHyperlinks
        all_links = soup.find_all('a', href=True)
        if all_links:
            ext_links = [link for link in all_links if not link['href'].startswith(('/', '#', 'mailto:', 'javascript:')) and hostname not in link['href']]
            features.append(len(ext_links) / len(all_links))
        else:
            features.append(0.0)
        
        # 28. PctExtResourceUrls
        resources = soup.find_all(['img', 'script', 'link'], src=True) + soup.find_all(['link'], href=True)
        if resources:
            ext_resources = []
            for res in resources:
                src = res.get('src') or res.get('href', '')
                if src and not src.startswith(('/', '#', 'data:', 'javascript:')) and hostname not in src:
                    ext_resources.append(res)
            features.append(len(ext_resources) / len(resources))
        else:
            features.append(0.0)
        
        # 29. ExtFavicon
        favicon = soup.find('link', rel=lambda x: x and 'icon' in x.lower())
        if favicon and favicon.get('href'):
            href = favicon['href']
            features.append(int(not href.startswith('/') and hostname not in href))
        else:
            features.append(0)
        
        # 30. InsecureForms
        forms = soup.find_all('form')
        insecure_forms = 0
        for form in forms:
            action = form.get('action', '')
            if action.startswith('http://') or (action.startswith('//') and not url.startswith('https')):
                insecure_forms += 1
        features.append(insecure_forms)
        
        # 31. RelativeFormAction
        relative_forms = sum(1 for form in forms if not form.get('action', '').startswith(('http://', 'https://')))
        features.append(relative_forms)
        
        # 32. ExtFormAction
        ext_forms = 0
        for form in forms:
            action = form.get('action', '')
            if action.startswith(('http://', 'https://')) and hostname not in action:
                ext_forms += 1
        features.append(ext_forms)
        
        # 33. AbnormalFormAction
        abnormal_forms = 0
        for form in forms:
            action = form.get('action', '')
            if action in ['', '#', 'javascript:void(0)', 'javascript:;']:
                abnormal_forms += 1
        features.append(abnormal_forms)
        
        # 34. PctNullSelfRedirectHyperlinks
        if all_links:
            null_links = [link for link in all_links if link['href'] in ['#', '', 'javascript:void(0)', 'javascript:;']]
            features.append(len(null_links) / len(all_links))
        else:
            features.append(0.0)
        
        # 35-44. JavaScript/Browser-dependent features (simplified)
        # These would typically require browser automation
        features.extend([0] * 10)  # Features 35-44
        
        # 45. UsingPopupWindow
        popup_indicators = ['window.open', 'popup', 'alert(', 'confirm(']
        script_content = ' '.join([script.get_text() for script in soup.find_all('script')])
        features.append(int(any(indicator in script_content.lower() for indicator in popup_indicators)))
    else:
        # If no HTML content, set all HTML-based features to 0
        features.extend([0.0] * 19)  # Features 27-45
    
    # 46. AgeofDomain
    domain_age = get_domain_age(domain)
    features.append(domain_age)
    
    # 47. DNSRecord
    features.append(check_dns_record(domain))
    
    # 48. GoogleIndex
    features.append(check_google_index(url))
    
    return features

def get_feature_names():
    """Return list of feature names"""
    return [
        'NumDots', 'SubdomainLevel', 'PathLevel', 'UrlLength', 'NumDash',
        'NumDashInHostname', 'AtSymbol', 'TildeSymbol', 'NumUnderscore', 'NumPercent',
        'NumQueryComponents', 'NumAmpersand', 'NumHash', 'NumNumericChars', 'NoHttps',
        'RandomString', 'IpAddress', 'DomainInSubdomains', 'DomainInPaths', 'HttpsInHostname',
        'HostnameLength', 'PathLength', 'QueryLength', 'DoubleSlashInPath', 'NumSensitiveWords',
        'EmbeddedBrandName', 'PctExtHyperlinks', 'PctExtResourceUrls', 'ExtFavicon', 'InsecureForms',
        'RelativeFormAction', 'ExtFormAction', 'AbnormalFormAction', 'PctNullSelfRedirectHyperlinks',
        'FrequentDomainNameMismatch', 'FakeLinkInStatusBar', 'RightClickDisabled', 'PopUpWindow',
        'SubmitInfoToEmail', 'IframeOrFrame', 'MissingTitle', 'ImagesOnlyInForm',
        'StatusBarCustomization', 'DisableRightClick', 'UsingPopupWindow', 'AgeofDomain',
        'DNSRecord', 'GoogleIndex'
    ]

# Example usage
if __name__ == "__main__":
    test_urls = [
        "https://www.google.com",
        "http://suspicious-site.com/login.php",
        "https://paypal-verification.fake-domain.com"
    ]
    
    feature_names = get_feature_names()
    
    for url in test_urls:
        print(f"\nAnalyzing: {url}")
        try:
            features = extract_features(url)
            print(f"Number of features extracted: {len(features)}")
            
            # Print first 10 features as example
            for i, (name, value) in enumerate(zip(feature_names[:10], features[:10])):
                print(f"{name}: {value}")
                
        except Exception as e:
            print(f"Error analyzing {url}: {str(e)}")